grbl_DD 
is exactly Grbl 0.9g, with PWM spindle control enabled exactly as per instructed on github.com/grbl/grbl.

GG Default EEPROM.txt
is the default EEPROM settings, which can be loaded to any 328p running Grbl 0.9g to replicate GG defaults.

GG 328p Code.hex
is the compiled binary of grbl_DD and can be loaded to any 328p.  XLoader works well.