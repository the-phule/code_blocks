DDcut.exe doesn't require installation; run it from anywhere.

GhostGunner requires the Arduino drivers for proper communication.  Install the drivers by running "install.bat" in the "drivers" folder or by right clicking on "arduino.inf" in the "drivers" folder and selecting install.  A restart is required before launching DDcut (an error will occur after installing the drive, but before restarting).

If you have the Arduino software installed on your computer then the Arduino drivers are already installed and you do not need to install them again.

Additional source files not contained herein are available by request at ghostgunner.net/forum.